const photoStack = document.querySelector('.photo-stack');
const images = document.querySelectorAll('.photo-stack img');
const leftArrow = document.querySelector('.left-arrow');
const rightArrow = document.querySelector('.right-arrow');
let currentIndex = 0;

function showImage(index) {
    images.forEach(img => img.style.opacity = '0');
    
    images[index].style.opacity = '1';
}

function showNextImage() {
    currentIndex = (currentIndex + 1) % images.length;
    showImage(currentIndex);
}

function showPreviousImage() {
    currentIndex = (currentIndex - 1 + images.length) % images.length;
    showImage(currentIndex);
}

showImage(currentIndex);

rightArrow.addEventListener('click', showNextImage);
leftArrow.addEventListener('click', showPreviousImage);


document.addEventListener('DOMContentLoaded', () => {
    const hamburger = document.querySelector('.hamburger-menu');
    const navigation = document.querySelector('.navigation');

    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navigation.classList.toggle('active');
    });
});