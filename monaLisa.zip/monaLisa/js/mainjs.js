let currentIndex = 0;
const photoContainer = document.querySelector('.photo-container');
const photos = document.querySelectorAll('.photo-container img');
const totalPhotos = photos.length;
let imagesToShow = window.innerWidth <= 600 ? 1 : 3;

function updateSlider() {
    imagesToShow = window.innerWidth <= 600 ? 1 : 3;
}

function cyclePhotos() {
    const offset = -(currentIndex * 100) / imagesToShow;
    photoContainer.style.transform = `translateX(${offset}%)`;

    if (currentIndex >= totalPhotos - imagesToShow) {
        setTimeout(() => {
            currentIndex = 0;
            photoContainer.style.transition = 'none';
            photoContainer.style.transform = 'translateX(0)';
            setTimeout(() => {
                photoContainer.style.transition = 'transform 1.5s ease';
            }, 20);
        }, 1500);
    } else {
        currentIndex++;
    }
}

function handleResize() {
    updateSlider();
    photoContainer.style.transition = window.innerWidth <= 600 ? 'none' : 'transform 1.5s ease';
    cyclePhotos(); 
}

window.addEventListener('resize', handleResize);

setInterval(cyclePhotos, 4000);



document.addEventListener('DOMContentLoaded', () => {
    const hamburger = document.querySelector('.hamburger-menu');
    const navigation = document.querySelector('.navigation');

    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navigation.classList.toggle('active');
    });
});